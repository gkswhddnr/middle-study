using System.Collections.Generic;
using UnityEngine;

// 공격 쿨다운을 관리하는 컴포넌트
// 쿨다운 계산 공식(attackSpeed → interval)이 한 곳에서만 존재한다
// 액션별로 독립적인 쿨다운을 가지므로 근접/원거리 쿨다운이 분리된다
public class AttackComponent
{
    private readonly Dictionary<MonsterAction, float> lastAttackTimes = new Dictionary<MonsterAction, float>();

    // 해당 액션이 공격 가능한 상태인지 확인한다
    // attackSpeed에서 interval로의 변환 공식은 이 컴포넌트가 단독으로 보유한다
    public bool CanAttack(MonsterAction action)
    {
        float interval = 1f / Mathf.Max(action.AttackSpeed, 0.01f);
        float lastTime = lastAttackTimes.TryGetValue(action, out float t) ? t : 0f;

        return Time.time - lastTime >= interval;
    }

    // 공격이 실행됐음을 등록한다
    public void RegisterAttack(MonsterAction action)
    {
        lastAttackTimes[action] = Time.time;
    }
}
