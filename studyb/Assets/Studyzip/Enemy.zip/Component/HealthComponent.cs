using System;
using UnityEngine;

// HP와 데미지 처리를 담당하는 컴포넌트
// 사망/피격은 이벤트로 외부에 알리고 후속 처리(시그널 발행 등)는 구독자가 결정한다
// 플레이어/몬스터 공용으로 사용 가능
public class HealthComponent
{
    private const float MIN_DAMAGE = 1f;

    private float maxHP;
    private float currentHP;
    private float defense;
    private bool isDead;

    public float MaxHP => maxHP;
    public float CurrentHP => currentHP;
    public bool IsDead => isDead;

    public event Action<float> OnDamaged;
    public event Action OnDied;

    public HealthComponent(float maxHP, float defense)
    {
        this.maxHP = Mathf.Max(1f, maxHP);
        this.currentHP = this.maxHP;
        this.defense = Mathf.Max(0f, defense);
    }

    public void TakeDamage(float damage)
    {
        if (isDead) return;

        float actualDamage = Mathf.Max(damage - defense, MIN_DAMAGE);
        currentHP -= actualDamage;

        if (currentHP <= 0)
        {
            currentHP = 0;
            isDead = true;
            OnDamaged?.Invoke(actualDamage);
            OnDied?.Invoke();
        }
        else
        {
            OnDamaged?.Invoke(actualDamage);
        }
    }

    public void SetDefense(float value)
    {
        defense = Mathf.Max(0f, value);
    }

    public void SetMaxHP(float value)
    {
        maxHP = Mathf.Max(1f, value);
        currentHP = Mathf.Min(currentHP, maxHP);
    }

    public void FullHeal()
    {
        currentHP = maxHP;
    }
}
