using UnityEngine;

// Transform 기반의 단순 이동을 담당하는 컴포넌트
// 추후 NavMeshAgent, Rigidbody 기반 구현으로 교체될 수 있고 넉백/슬로우 같은 효과의 단일 진입점이 된다
public class MovementComponent
{
    private readonly Transform owner;
    private readonly Animator animator;

    public float MoveSpeed { get; private set; }

    public MovementComponent(Transform owner, Animator animator, float moveSpeed)
    {
        this.owner = owner;
        this.animator = animator;
        MoveSpeed = Mathf.Max(0f, moveSpeed);
    }

    public void SetMoveSpeed(float value)
    {
        MoveSpeed = Mathf.Max(0f, value);
    }

    // 지정한 월드 좌표를 향해 한 프레임 분량 이동한다
    // y축은 평면 이동을 위해 무시한다
    public void MoveTowards(Vector3 worldPosition)
    {
        Vector3 dir = worldPosition - owner.position;
        dir.y = 0f;

        if (dir.sqrMagnitude <= 0.01f)
        {
            StopWalking();
            return;
        }

        Vector3 normalized = dir.normalized;
        owner.position += normalized * MoveSpeed * Time.deltaTime;
        owner.rotation = Quaternion.LookRotation(normalized);

        if (animator != null)
        {
            animator.SetBool(AnimatorParams.IsWalking, true);
        }
    }

    // 이동 없이 회전만 수행한다
    public void FaceTowards(Vector3 worldPosition)
    {
        Vector3 dir = worldPosition - owner.position;
        dir.y = 0f;

        if (dir.sqrMagnitude <= 0.01f) return;

        owner.rotation = Quaternion.LookRotation(dir.normalized);
    }

    // 걷기 상태를 명시적으로 종료한다
    // HitState/DeathState 같은 인터럽트 진입 시 호출
    public void StopWalking()
    {
        if (animator != null)
        {
            animator.SetBool(AnimatorParams.IsWalking, false);
        }
    }
}
