using UnityEngine;

[CreateAssetMenu(fileName = "MeleeAttackAction", menuName = "Enemy/Action/MeleeAttackAction")]
public class MeleeAttackAction : MonsterAction
{
    [Tooltip("공격 시 발동할 Animator Trigger 이름. 비워두면 애니메이션 재생을 건너뜁니다")]
    [SerializeField] private string animTrigger = "Attack";

    public override void Act(Monster monster)
    {
        if (!monster.Attack.CanAttack(this)) return;
        monster.Attack.RegisterAttack(this);

        if (!string.IsNullOrEmpty(animTrigger))
        {
            monster.Animator.SetTrigger(animTrigger);
        }

        if (monster.Target == null) return;

        float distance = Vector3.Distance(monster.Target.position, monster.transform.position);
        Debug.Assert(distance <= monster.Stat.attackRange, "MeleeAttack에 들어왔는데 사거리 밖이다");

        IDamageable damageable = monster.Target.GetComponent<IDamageable>();
        damageable?.TakeDamage(monster.AttackPower);
    }
}
