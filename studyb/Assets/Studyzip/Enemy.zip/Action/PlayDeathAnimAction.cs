using UnityEngine;

[CreateAssetMenu(fileName = "PlayDeathAnimAction", menuName = "Enemy/Action/PlayDeathAnimAction")]
public class PlayDeathAnimAction : MonsterAction
{
    public override void Act(Monster monster)
    {
        monster.Animator.SetTrigger(AnimatorParams.Death);
    }
}
