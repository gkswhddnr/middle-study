using UnityEngine;

// HitState/DeathState 등 인터럽트 상태의 enterActions 첫 항목으로 넣어
// ChaseState에서 켜진 IsWalking 등이 그대로 남는 문제를 방지한다
[CreateAssetMenu(fileName = "StopAction", menuName = "Enemy/Action/StopAction")]
public class StopAction : MonsterAction
{
    public override void Act(Monster monster)
    {
        monster.Movement.StopWalking();
    }
}
