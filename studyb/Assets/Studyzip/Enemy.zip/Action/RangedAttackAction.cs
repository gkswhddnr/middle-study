using UnityEngine;

[CreateAssetMenu(fileName = "RangedAttackAction", menuName = "Enemy/Action/RangedAttackAction")]
public class RangedAttackAction : MonsterAction
{
    [Tooltip("공격 시 발동할 Animator Trigger 이름. 비워두면 애니메이션 재생을 건너뜁니다")]
    [SerializeField] private string animTrigger = "Attack";
    [SerializeField] private Projectile projectilePrefab;
    [SerializeField] private float projectileSpeed = 10f;
    [SerializeField] private Vector3 offset = new Vector3(0f, 1f, 0f);

    public override void Act(Monster monster)
    {
        if (!monster.Attack.CanAttack(this)) return;
        monster.Attack.RegisterAttack(this);

        if (!string.IsNullOrEmpty(animTrigger))
        {
            monster.Animator.SetTrigger(animTrigger);
        }

        if (monster.Target == null || projectilePrefab == null) return;

        Vector3 spawnPos = monster.transform.position + offset;
        Projectile instance = Instantiate(projectilePrefab, spawnPos, Quaternion.identity);

        Vector3 dir = (monster.Target.position + offset - spawnPos).normalized;
        instance.Init(dir, projectileSpeed, monster.AttackPower, monster.gameObject);
    }
}
