using UnityEngine;

[CreateAssetMenu(fileName = "FaceTargetAction", menuName = "Enemy/Action/FaceTargetAction")]
public class FaceTargetAction : MonsterAction
{
    public override void Act(Monster monster)
    {
        if (monster.Target == null) return;

        monster.Movement.FaceTowards(monster.Target.position);
    }
}
