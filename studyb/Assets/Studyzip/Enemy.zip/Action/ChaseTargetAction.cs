using UnityEngine;

[CreateAssetMenu(fileName = "ChaseTargetAction", menuName = "Enemy/Action/ChaseTargetAction")]
public class ChaseTargetAction : MonsterAction
{
    public override void Act(Monster monster)
    {
        if (monster.Target == null) return;

        monster.Movement.MoveTowards(monster.Target.position);
    }
}
