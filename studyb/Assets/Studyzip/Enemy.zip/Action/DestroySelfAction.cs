using UnityEngine;

[CreateAssetMenu(fileName = "DestroySelfAction", menuName = "Enemy/Action/DestroySelfAction")]
public class DestroySelfAction : MonsterAction
{
    [SerializeField] private float delay = 2f;

    public override void Act(Monster monster)
    {
        Object.Destroy(monster.gameObject, delay);
    }
}
