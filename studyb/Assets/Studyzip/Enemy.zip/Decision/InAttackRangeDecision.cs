using UnityEngine;

[CreateAssetMenu(fileName = "InAttackRangeDecision", menuName = "Enemy/Decision/InAttackRangeDecision")]
public class InAttackRangeDecision : Decision
{
    public override bool Decide(Monster monster)
    {
        if (monster.Target == null) return false;

        float sqrDist = (monster.Target.position - monster.transform.position).sqrMagnitude;
        float range = monster.Stat.attackRange;

        return sqrDist <= range * range;
    }
}
