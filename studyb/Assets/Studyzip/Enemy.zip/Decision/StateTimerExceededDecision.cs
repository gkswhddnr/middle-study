using UnityEngine;

[CreateAssetMenu(fileName = "StateTimerExceededDecision", menuName = "Enemy/Decision/StateTimerExceededDecision")]
public class StateTimerExceededDecision : Decision
{
    [Tooltip("상태 진입 후 이 시간(초)을 경과하면 true를 반환합니다")]
    [SerializeField] private float duration = 1f;

    public override bool Decide(Monster monster)
    {
        return monster.StateTimer >= duration;
    }
}
