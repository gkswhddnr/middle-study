using UnityEngine;

public class Monster : Actor
{
    [Header("정보")]
    [SerializeField] private MonsterStatSO stat;
    [SerializeField] private FSMConfig fsmConfig;
    [SerializeField] private Transform target;

    private FSMComponent fsm;
    private AttackComponent attack;
    private bool isReady;
    private float attackMultiplier = 1f;

    public MonsterStatSO Stat => stat;
    public Transform Target => target;
    public AttackComponent Attack => attack;
    public float StateTimer => fsm != null ? fsm.StateTimer : 0f;
    public float AttackPower => stat != null ? stat.attack * attackMultiplier : 0f;

    protected override void OnAwake()
    {
        if (stat == null)
        {
            Debug.LogError($"[{name}] MonsterStatSO가 할당되지 않았습니다", this);
            return;
        }

        if (fsmConfig == null)
        {
            Debug.LogError($"[{name}] FSMConfig가 할당되지 않았습니다", this);
            return;
        }

        // 공용 컴포넌트(Movement, Health)는 Actor가 초기화한다
        InitActor(stat.maxHP, stat.defense, stat.moveSpeed);

        // 몬스터 전용 컴포넌트
        attack = new AttackComponent();
        fsm = new FSMComponent(this, fsmConfig);

        // HealthComponent의 이벤트를 FSM 시그널로 연결한다
        // 이 어댑터 패턴이 도메인 컴포넌트(Health)와 FSM 시스템의 결합을 끊어준다
        health.OnDamaged += HandleDamaged;
        health.OnDied += HandleDied;

        isReady = true;
    }

    private void OnDestroy()
    {
        if (health != null)
        {
            health.OnDamaged -= HandleDamaged;
            health.OnDied -= HandleDied;
        }
    }

    // FSM.Init은 target 세팅 이후에 실행되어야 하므로 OnStart에서 호출한다
    // OnAwake로 옮기지 말 것
    protected override void OnStart()
    {
        if (!isReady) return;

        if (target == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                target = player.transform;
            }
        }

        fsm.Init();
    }

    // 매 프레임 갱신이 필요한 컴포넌트의 Tick을 액터가 일괄 호출한다
    // (현재는 fsm만. 추후 상태를 가지는 컴포넌트가 추가되면 여기로 모임)
    protected override void OnTick()
    {
        if (!isReady) return;

        // 사망 후에도 DeathState의 enter/continue 액션이 정상 동작하도록 가드 제거
        // DeathState는 terminal 상태이므로 외부로 나가는 transition이 없다는 컨벤션을 따른다
        fsm.Tick();
    }

    public void ChangeState(State newState)
    {
        if (!isReady) return;
        fsm.ChangeState(newState);
    }

    public void SendSignal(MonsterSignal signal)
    {
        // 외부 진입점은 Unity 콜백이 아니므로 isReady로 명시적 게이팅
        if (!isReady) return;
        fsm.SendSignal(signal);
    }

    // 웨이브 보정치(HP/공격/방어 배율)를 적용한다. 스폰 직후 SpawnSystem이 호출한다.
    public void ApplyWaveScaling(float hpMul, float atkMul, float defMul)
    {
        if (health == null) return;

        health.SetMaxHP(stat.maxHP * hpMul);
        health.FullHeal();
        health.SetDefense(stat.defense * defMul);
        attackMultiplier = atkMul;
    }

    // HealthComponent 이벤트와 FSM 시그널을 연결하는 어댑터
    // 사망이 일반 피격보다 우선이므로 OnDied가 먼저 호출되어 Hit 시그널은 발행되지 않는다
    private void HandleDamaged(float actualDamage)
    {
        if (health.IsDead) return;
        SendSignal(MonsterSignal.Hit);
    }

    private void HandleDied()
    {
        SendSignal(MonsterSignal.Death);
    }
}
