using UnityEngine;

public static class AnimatorParams
{
    public static readonly int IsWalking = Animator.StringToHash("IsWalking");
    public static readonly int Attack = Animator.StringToHash("Attack");
    public static readonly int Death = Animator.StringToHash("Death");
}
