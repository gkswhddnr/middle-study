using UnityEngine;

// 액션마다 독립적인 attackSpeed를 인스펙터에서 설정할 수 있다
// MonsterStatSO의 attackSpeed는 제거됨
// 쿨다운 공식(attackSpeed → interval)은 AttackComponent가 단독으로 보유한다
public abstract class MonsterAction : ScriptableObject
{
    [SerializeField] private float attackSpeed = 1f;
    public float AttackSpeed => attackSpeed;

    public abstract void Act(Monster monster);
}
