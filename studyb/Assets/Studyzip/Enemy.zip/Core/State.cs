using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "State", menuName = "Enemy/Core/State")]
public class State : ScriptableObject
{
    public List<MonsterAction> enterActions;
    public List<MonsterAction> continueActions;
    public List<MonsterAction> exitActions;
    public List<Transition> transitions;

    public void Enter(Monster monster)
    {
        if (enterActions == null) return;

        foreach (MonsterAction action in enterActions)
        {
            if (action != null)
            {
                action.Act(monster);
            }
        }
    }

    public void Exit(Monster monster)
    {
        if (exitActions == null) return;

        foreach (MonsterAction action in exitActions)
        {
            if (action != null)
            {
                action.Act(monster);
            }
        }
    }

    // 트랜지션을 먼저 검사하고 전이가 발생했다면 즉시 종료
    // 그렇지 않으면 continueActions를 실행
    public void UpdateState(Monster monster)
    {
        if (transitions != null)
        {
            foreach (Transition transition in transitions)
            {
                if (transition.decision != null && transition.decision.Decide(monster))
                {
                    monster.ChangeState(transition.nextState);
                    return;
                }
            }
        }

        if (continueActions == null) return;

        foreach (MonsterAction action in continueActions)
        {
            if (action != null)
            {
                action.Act(monster);
            }
        }
    }
}
