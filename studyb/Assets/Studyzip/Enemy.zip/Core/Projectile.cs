using UnityEngine;

[RequireComponent(typeof(Collider))]
public class Projectile : MonoBehaviour
{
    [SerializeField] private float lifeTime = 3f;

    private Vector3 dir;
    private float speed;
    private float dmg;
    private GameObject owner;

    private void Update()
    {
        transform.position += dir * speed * Time.deltaTime;
    }

    public void Init(Vector3 direction, float speedValue, float damage, GameObject owner)
    {
        dir = direction;
        speed = speedValue;
        dmg = damage;
        this.owner = owner;

        Destroy(gameObject, lifeTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        // 발사자 자신에게는 충돌 무시
        if (other.gameObject == owner) return;

        IDamageable damageable = other.GetComponent<IDamageable>();
        if (damageable != null)
        {
            damageable.TakeDamage(dmg);
            Destroy(gameObject);
        }
    }
}
