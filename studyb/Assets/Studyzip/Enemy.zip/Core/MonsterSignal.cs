public enum MonsterSignal
{
    Hit,
    Death,
    Stun,
    Knockback
}
