using UnityEngine;

// Monster, Player 등 모든 액터의 베이스 클래스
// 공용 컴포넌트(이동, 체력)와 IDamageable 구현을 담당한다
// 액터 고유의 로직(FSM, 입력 등)은 각 서브클래스가 추가 컴포넌트로 가진다
public abstract class Actor : MonoBehaviour, IDamageable
{
    protected MovementComponent movement;
    protected HealthComponent health;
    protected Animator actorAnimator;

    public MovementComponent Movement => movement;
    public HealthComponent Health => health;
    public Animator Animator => actorAnimator;
    public bool IsDead => health != null && health.IsDead;
    public float Def { get; protected set; }

    // Unity 생명주기는 Actor가 독점한다
    // 서브클래스는 Awake/Start/Update 대신 OnAwake/OnStart/OnTick을 override해서 구현한다
    private void Awake() { OnAwake(); }
    private void Start() { OnStart(); }
    private void Update() { OnTick(); }

    protected virtual void OnAwake() { }
    protected virtual void OnStart() { }
    protected virtual void OnTick() { }

    // 서브클래스 OnAwake에서 null 체크 후 호출한다
    protected void InitActor(float maxHP, float defense, float moveSpeed)
    {
        Def = defense;  

        // Animator는 액터 루트 또는 비주얼 자식 오브젝트에 있을 수 있다
        actorAnimator = GetComponentInChildren<Animator>();
        movement = new MovementComponent(transform, actorAnimator, moveSpeed);
        health = new HealthComponent(maxHP, defense);
    }

    // IDamageable 구현은 HealthComponent에 위임한다
    // 실제 피격/사망 반응은 서브클래스가 health 이벤트를 구독해서 처리한다
    public void TakeDamage(float damage)
    {
        if (health == null) return;  // 초기화 실패 시 방어. health 존재 여부가 isReady 역할을 대신한다
        health.TakeDamage(damage);
    }
}
