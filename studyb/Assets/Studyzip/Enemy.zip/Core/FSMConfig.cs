using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "FSMConfig", menuName = "Enemy/Core/FSMConfig")]
public class FSMConfig : ScriptableObject
{
    [SerializeField] private State startState;
    [SerializeField] private List<SignalTransition> globalSignalTransitions;

    public State StartState => startState;
    public IReadOnlyList<SignalTransition> GlobalSignalTransitions => globalSignalTransitions;

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (startState == null)
        {
            Debug.LogWarning($"[{name}] startState가 비어있습니다", this);
        }

        if (globalSignalTransitions == null) return;

        var seen = new HashSet<MonsterSignal>();
        for (int i = 0; i < globalSignalTransitions.Count; i++)
        {
            var t = globalSignalTransitions[i];
            if (t == null) continue;

            if (!seen.Add(t.signal))
            {
                Debug.LogWarning($"[{name}] {t.signal} 시그널이 중복 등록되었습니다", this);
            }

            if (t.nextState == null)
            {
                Debug.LogWarning($"[{name}] globalSignalTransitions[{i}]의 nextState가 비어있습니다", this);
                continue;
            }

            // Death 시그널이 향하는 State는 terminal이어야 한다
            // 외부 transition이 있으면 죽은 몬스터가 다른 상태로 다시 전이될 수 있음
            if (t.signal == MonsterSignal.Death &&
                t.nextState.transitions != null &&
                t.nextState.transitions.Count > 0)
            {
                Debug.LogWarning($"[{name}] DeathState({t.nextState.name})에 외부 transition이 있습니다. terminal이어야 합니다", this);
            }
        }
    }
#endif
}
