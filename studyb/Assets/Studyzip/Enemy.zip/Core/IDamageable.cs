public interface IDamageable
{
    float Def { get; }
    void TakeDamage(float damage);
}
