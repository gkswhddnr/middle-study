[System.Serializable]
public class SignalTransition
{
    public MonsterSignal signal;
    public State nextState;
}
