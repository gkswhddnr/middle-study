using UnityEngine;

public class FSMComponent
{
    private readonly Monster owner;
    private readonly FSMConfig config;
    private State currentState;

    public State CurrentState => currentState;
    public float StateTimer { get; private set; }

    public FSMComponent(Monster owner, FSMConfig config)
    {
        this.owner = owner;
        this.config = config;
    }

    public void Init()
    {
        if (config == null || config.StartState == null) return;

        currentState = config.StartState;
        StateTimer = 0f;
        currentState.Enter(owner);
    }

    public void Tick()
    {
        if (currentState == null) return;

        StateTimer += Time.deltaTime;
        currentState.UpdateState(owner);
    }

    public void ChangeState(State newState)
    {
        if (newState == null) return;

        // 동일 상태로의 전이는 enter/exit를 다시 호출하지 않되 타이머는 리셋한다
        // (Hit 도중 또 피격 시 hitStun 시간 갱신 - 스턴락 허용)
        // 안티 스턴락이 필요한 케이스는 데이터(쿨다운, 별도 Decision)로 표현할 것
        if (newState == currentState)
        {
            StateTimer = 0f;
            return;
        }

        if (currentState != null)
        {
            currentState.Exit(owner);
        }

        currentState = newState;
        StateTimer = 0f;
        currentState.Enter(owner);
    }

    // 외부에서 들어온 인터럽트를 글로벌 트랜지션으로 처리
    public void SendSignal(MonsterSignal signal)
    {
        // 사망 후에는 어떤 시그널도 무시한다
        if (owner.IsDead && signal != MonsterSignal.Death) return;

        if (config == null || config.GlobalSignalTransitions == null) return;

        foreach (var transition in config.GlobalSignalTransitions)
        {
            if (transition == null) continue;
            if (transition.signal == signal)
            {
                ChangeState(transition.nextState);
                return;
            }
        }

#if UNITY_EDITOR
        Debug.LogWarning($"[{owner.name}] {signal} 시그널에 매칭되는 트랜지션이 없습니다", owner);
#endif
    }
}
